#include <stdio.h>
#include "mpi.h"

void main (int argc, char **argv) {
	char		mensagem[] = "Exemplo de mensagem...";
	int		i, process_rank, process_quant, type=99;
	int		err_id;
	MPI_Status	status;

	err_id	= MPI_Init(&argc, &argv);
	err_id  = MPI_Comm_size(MPI_COMM_WORLD, &process_quant);
	err_id  = MPI_Comm_rank(MPI_COMM_WORLD, &process_rank);
	if (process_rank == 0)
		for(i=1; i<process_quant; i++)
			MPI_Send(mensagem, 21, MPI_CHAR, i, type, MPI_COMM_WORLD);
	else
		MPI_Recv(mensagem, 21, MPI_CHAR, 0, type, MPI_COMM_WORLD, &status);

	printf("Processo: %d, Mensagem: %s \n", process_rank, mensagem);
	MPI_Finalize();
} /*fim-main */
